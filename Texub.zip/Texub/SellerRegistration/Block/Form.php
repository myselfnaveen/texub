<?php
 
namespace Texub\SellerRegistration\Block;
 
use Magento\Framework\View\Element\Template;
 
use Magento\Backend\Block\Template\Context;
 
use Magento\Directory\Model\ResourceModel\Country\CollectionFactory;
 
class Form extends Template
 
{
 
    protected $_countryCollectionFactory;
     
    public function __construct(
        CollectionFactory $countryCollectionFactory,
        Context $context, 
        array $data = []
    )
    {
        $this->_countryCollectionFactory = $countryCollectionFactory;
        parent::__construct($context, $data);
    }
     
    public function getCountryCollection()
    {
     
        $collection = $this->_countryCollectionFactory->create()->loadByStore();
        return $collection;
     
    }
     
    public function getCountries()
    {
     
        return $this->getCountryCollection()->toOptionArray();
     
    }

    public function getAllRole()
    {
        $role = array('Chairman \ President \ C Suite', 'Investor', 'CEO', 'Director', 'Manager', 'Consultant', 'VP \ SVP \ EVP', 'Sales Head', 'Other');
        $rol =    '<select name="customer_role" id="customer_role">';
        foreach($role as $val)
        {
            $rol .=    '<option  value="'.$val.'">'.$val.'.</option>';
        }
        $rol .= "</select>";
        return $rol;

    }

    public function getRegion()
    {

        $region = array('Asia', 'Middle East', 'CIS', 'EU');
        $reg =    '<select name="region" id="region">';
        foreach($region as $value)
        {
            $reg .=    '<option  value="'.$value.'">'.$value.'.</option>';
        }
        $reg .= "</select>";
        return $reg;

    }
 
}
 
?>