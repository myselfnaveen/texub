<?php
namespace Texub\SellerRegistration\Model\ResourceModel\Post;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'region_id';
	protected $_eventPrefix = 'region_list_table_collection';
	protected $_eventObject = 'region_list_collection';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct()
	{
		$this->_init('Texub\SellerRegistration\Model\Post', 'Texub\SellerRegistration\Model\ResourceModel\Post');
	}

}
