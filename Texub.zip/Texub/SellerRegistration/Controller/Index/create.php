<?php
 
namespace Texub\SellerRegistration\Controller\Index;

use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\Translate\Inline\StateInterface;
use Psr\Log\LoggerInterface;

class Create extends \Magento\Framework\App\Action\Action
 
{
    protected $_pageFactory;
    protected $customer;
    protected $customerFactory;
    protected $customerModel;
    protected $customerAccountManagement;

    protected $transportBuilder;
    protected $inlineTranslation;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface MpSellerFactory $mpSellerFactory,
     */
    protected $storeManager;
    public function __construct(
        \Psr\Log\LoggerInterface $_logger,
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Magento\Customer\Model\Customer $customer,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Texub\GuestRegistration\Model\Customer $customerModel,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Webkul\Marketplace\Model\SellerFactory $mpSellerFactory,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        \Magento\Customer\Api\AccountManagementInterface $customerAccountManagement,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Magento\Customer\Model\Session $customerSession,
        TransportBuilder $transportBuilder,
        StateInterface $state
    )
    {
        $this->_logger = $_logger;
        $this->customer = $customer;
        $this->customerFactory = $customerFactory;
        $this->_pageFactory = $pageFactory;
        $this->customerModel = $customerModel;
        $this->storeManager     = $storeManager;
        $this->mpSellerFactory = $mpSellerFactory;
        $this->customerAccountManagement = $customerAccountManagement;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->customerSession = $customerSession;
        $this->_date = $date;
        $this->transportBuilder = $transportBuilder;
        $this->inlineTranslation = $state;
        return parent::__construct($context);
    }
    public function execute()
    {
        $postData = $this->getRequest()->getPostValue();
        if ($this->customerModel->userExists($postData['seller_email'])) {
            $response = [
                'errors' => true,
                'message' => __('A user already exists with this email id.')
            ];
        } else {
            try {
                $shopUrl = explode("@",$postData['seller_email']);
                $customer = $this->customerFactory->create();
                $customer->setEmail($postData['seller_email']);
                $customer->setFirstname($postData['seller_first_name']);
                $customer->setLastname($postData['seller_last_name']);
                $customer->setPassword($postData['seller_password']);
                $customer->setCustomerDesignation($postData['seller_designation']);
                $customer->setCustomerMobileNumber($postData['seller_mobile_number']);
                $customer->setCustomerCompanyName($postData['seller_company_name']);
                $customer->setCustomerRegion($postData['customer_region']);
                $customer->setCustomerCountry($postData['customer_country']);
                $customer->setCustomerRole($postData['customer_role']);
                $customer->setKycStatus(0);
                $customer->setIsSeller(1);
                $customer->setShopUrl($shopUrl[0]);
                $customer->setGroupId(6);
                $customer->setWebsiteId($this->getWebsiteId());
                $customer->save();
                if($customer->save()) {
                    $customerId = $customer->getId();
                    $model = $this->mpSellerFactory->create();
                    $model->setData('is_seller', $postData['is_seller']);
                    $model->setData('seller_id', $customerId);
                    $model->setData('store_id', 0);
                    $model->setCreatedAt($this->_date->gmtDate());
                    $model->setUpdatedAt($this->_date->gmtDate());
                    $model->setAdminNotification(1);
                    $model->save();

                    $customer = $this->customerAccountManagement->authenticate(
                        $postData['seller_email'],
                        $postData['seller_password']
                    );
                    $this->customerSession->setCustomerDataAsLoggedIn($customer);
                    $this->customerSession->regenerateId();
                    try {
                        $templateId = 'customer_create_account_email_template';
                        $fromEmail = 'admin@texub.com';
                        $fromName = 'Texub Admin';
                        $toEmail = $postData['seller_email'];
                        $name = $postData['seller_first_name']." ".$postData['seller_last_name'];

                        $emailTempVariables['name'] = $name;
                        $emailTempVariables['email'] = $postData['seller_email'];

                        $storeId = $this->storeManager->getStore()->getId();

                        $from = ['email' => $fromEmail, 'name' => $fromName];
                        $this->inlineTranslation->suspend();

                        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

                        $templateOptions = [
                            'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                            'store' => $storeId
                        ];

                        $postObject = new \Magento\Framework\DataObject();
                        $postObject->setData($emailTempVariables);

                        $transport = $this->transportBuilder->setTemplateIdentifier($templateId, $storeScope)
                        ->setTemplateOptions($templateOptions)
                        ->setTemplateVars(['customer' => $postObject])
                        ->setFrom($from)
                        ->addTo($toEmail)
                        ->getTransport();
                        $transport->sendMessage();
                        $this->inlineTranslation->resume();
                    } catch (\Exception $e) {
                        $this->_logger->info($e->getMessage());
                    }
                }
            } catch (Exception $e) {
                $this->messageManager->addError(__('An error occured while saving customer.'));
            }
        }
        $resultRedirect = $this->resultRedirectFactory->create();
        $resultRedirect->setPath('/');
        return $resultRedirect;
    }

    public function getWebsiteId()
    {
        return $this->storeManager->getWebsite()->getWebsiteId();
    }
}