<?php
 
namespace Texub\SellerRegistration\Controller\Index;
 
class Index extends \Magento\Framework\App\Action\Action
 
{
    protected $_pageFactory;
    protected $customer;
    protected $customerFactory;
    protected $customerSession;
    protected $resultRedirectFactory;
    protected $_postFactory;
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Magento\Customer\Model\Session $session,
        \Texub\SellerRegistration\Model\PostFactory $postFactory,
        \Magento\Framework\Controller\Result\Redirect $resultRedirect
    )
    {
        $this->_pageFactory = $pageFactory;
        $this->_postFactory = $postFactory;
        $this->_customerSession = $session;
        $this->_resultRedirectFactory = $resultRedirect;
        return parent::__construct($context);
    }
    public function execute()
    {
        $post = $this->_postFactory->create();
		$collection = $post->getCollection();
		foreach($collection as $item){
			echo "<pre>";
			print_r($item->getData());
			echo "</pre>";
		}
		exit();
		return $this->_pageFactory->create();


        if($this->_customerSession->isLoggedIn()){
            $resultRedirect = $this->resultRedirectFactory->create();
            $resultRedirect->setPath('/');
            return $resultRedirect;
        } else {
            $resultPage = $this->_pageFactory->create();
            $resultPage->getConfig()->getTitle()->set('Seller Registration');
            return $resultPage;
        }
        
    }
}