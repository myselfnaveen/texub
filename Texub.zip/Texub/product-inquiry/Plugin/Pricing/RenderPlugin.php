<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Texub\ProductInquiry\Plugin\Pricing;

use Magento\Framework\Registry;
use Magento\Framework\View\Element\Template;

/**
 * Class RenderPlugin
 * @package Texub\ProductInquiry\Plugin\Pricing
 */
class RenderPlugin extends \Magento\Catalog\Pricing\Render
{
    /**
     * RenderPlugin constructor.
     * @param Template\Context $context
     * @param Registry $registry
     * @param \Texub\ProductInquiry\Helper\Data $helperData
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        Registry $registry,
        \Texub\ProductInquiry\Helper\Data $helperData,
        array $data = []
    ) {
        $this->helperData = $helperData;
        parent::__construct($context, $registry, $data);
    }

    /**
     * @return string
     */
    protected function _toHtml()
    {
        $product = $this->getProduct();
        $disclosePrice = $this->helperData->getDisclosePrice($product->getId());

        if ($disclosePrice) {
            return parent::_toHtml();
        } else {
            return '';
        }
    }
}
