<?php
namespace Texub\ProductInquiry\Model;

class ProductInquiry extends \Magento\Framework\Model\AbstractModel
{
    const CACHE_TAG = 'texub_product_inquiry_post';
    protected $_cacheTag = 'texub_product_inquiry_post';
    protected $_eventPrefix = 'texub_product_inquiry_post';
    protected function _construct()
    {
        $this->_init(\Texub\ProductInquiry\Model\ResourceModel\ProductInquiry::class);
    }
}
