<?php
namespace Texub\ProductInquiry\Model\ResourceModel\ProductInquiry;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'entity_id';
    protected $_eventPrefix = 'texub_product_inquiry_post_collection';
    protected $_eventObject = 'product_inquiry_collection';

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Texub\ProductInquiry\Model\ProductInquiry::class, \Texub\ProductInquiry\Model\ResourceModel\ProductInquiry::class);
    }
}
